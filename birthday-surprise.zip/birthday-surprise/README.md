# 💖 Interactive Birthday Surprise

Static site (HTML + CSS + vanilla JS). Deploy on GitHub Pages by uploading `index.html`, `style.css`, `script.js` and `assets/`.

## Journey
Open surprise → light candle → blow candle → cut cake → "Are you still crazy about me?" (moving YES) → envelope & birthday card → **25 Little Reasons Why I Love You** → **Question Session** (7 questions + final emotional question) → Happy 25th Birthday finale → Replay.

There is no photo gallery.

## Customize
Edit the `CONFIG` object at the top of `script.js`. Reasons live in `REASONS_DATA`, questions in the quiz data array.

## Music
Put your song at `assets/music.mp3`.
